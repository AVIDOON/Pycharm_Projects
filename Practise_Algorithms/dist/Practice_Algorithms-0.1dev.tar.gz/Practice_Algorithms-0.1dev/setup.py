from distutils.core import setup

setup(
   name='Practice_Algorithms',
   version='0.1dev',
   packages=['packaging',],
   license='MIT',
   long_description=open('README.txt').read(),
)