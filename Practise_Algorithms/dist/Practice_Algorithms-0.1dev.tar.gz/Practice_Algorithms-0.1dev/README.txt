Please read this before using this library.
This consists of the following algorithms along with their respective time complexities.
